

```python
import numpy as np
import pandas as pd
import tensorflow as tf
import keras
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import GridSearchCV
import seaborn as sns
import matplotlib
import matplotlib.pyplot as plt
sns.set()

import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.utils import to_categorical
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
```


```python
INPUT_DIR= "./data/input"
OUTPUT_DIR= "./data/output"
```


```python
train_df = pd.read_csv(INPUT_DIR+r"/dengue_features_train.csv")
test_df = pd.read_csv(INPUT_DIR+r"/dengue_features_test.csv")
train_label = pd.read_csv(INPUT_DIR+r"/dengue_labels_train.csv")["total_cases"]
```


```python
print(train_label.describe())
print()
print(train_label.sample(5))
```

    count    1456.000000
    mean       24.675137
    std        43.596000
    min         0.000000
    25%         5.000000
    50%        12.000000
    75%        28.000000
    max       461.000000
    Name: total_cases, dtype: float64
    
    1218     7
    582     22
    851     23
    1051    22
    112     29
    Name: total_cases, dtype: int64



```python
train_df.head(25)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>year</th>
      <th>weekofyear</th>
      <th>week_start_date</th>
      <th>ndvi_ne</th>
      <th>ndvi_nw</th>
      <th>ndvi_se</th>
      <th>ndvi_sw</th>
      <th>precipitation_amt_mm</th>
      <th>reanalysis_air_temp_k</th>
      <th>...</th>
      <th>reanalysis_precip_amt_kg_per_m2</th>
      <th>reanalysis_relative_humidity_percent</th>
      <th>reanalysis_sat_precip_amt_mm</th>
      <th>reanalysis_specific_humidity_g_per_kg</th>
      <th>reanalysis_tdtr_k</th>
      <th>station_avg_temp_c</th>
      <th>station_diur_temp_rng_c</th>
      <th>station_max_temp_c</th>
      <th>station_min_temp_c</th>
      <th>station_precip_mm</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sj</td>
      <td>1990</td>
      <td>18</td>
      <td>1990-04-30</td>
      <td>0.122600</td>
      <td>0.103725</td>
      <td>0.198483</td>
      <td>0.177617</td>
      <td>12.42</td>
      <td>297.572857</td>
      <td>...</td>
      <td>32.00</td>
      <td>73.365714</td>
      <td>12.42</td>
      <td>14.012857</td>
      <td>2.628571</td>
      <td>25.442857</td>
      <td>6.900000</td>
      <td>29.4</td>
      <td>20.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sj</td>
      <td>1990</td>
      <td>19</td>
      <td>1990-05-07</td>
      <td>0.169900</td>
      <td>0.142175</td>
      <td>0.162357</td>
      <td>0.155486</td>
      <td>22.82</td>
      <td>298.211429</td>
      <td>...</td>
      <td>17.94</td>
      <td>77.368571</td>
      <td>22.82</td>
      <td>15.372857</td>
      <td>2.371429</td>
      <td>26.714286</td>
      <td>6.371429</td>
      <td>31.7</td>
      <td>22.2</td>
      <td>8.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sj</td>
      <td>1990</td>
      <td>20</td>
      <td>1990-05-14</td>
      <td>0.032250</td>
      <td>0.172967</td>
      <td>0.157200</td>
      <td>0.170843</td>
      <td>34.54</td>
      <td>298.781429</td>
      <td>...</td>
      <td>26.10</td>
      <td>82.052857</td>
      <td>34.54</td>
      <td>16.848571</td>
      <td>2.300000</td>
      <td>26.714286</td>
      <td>6.485714</td>
      <td>32.2</td>
      <td>22.8</td>
      <td>41.4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>sj</td>
      <td>1990</td>
      <td>21</td>
      <td>1990-05-21</td>
      <td>0.128633</td>
      <td>0.245067</td>
      <td>0.227557</td>
      <td>0.235886</td>
      <td>15.36</td>
      <td>298.987143</td>
      <td>...</td>
      <td>13.90</td>
      <td>80.337143</td>
      <td>15.36</td>
      <td>16.672857</td>
      <td>2.428571</td>
      <td>27.471429</td>
      <td>6.771429</td>
      <td>33.3</td>
      <td>23.3</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sj</td>
      <td>1990</td>
      <td>22</td>
      <td>1990-05-28</td>
      <td>0.196200</td>
      <td>0.262200</td>
      <td>0.251200</td>
      <td>0.247340</td>
      <td>7.52</td>
      <td>299.518571</td>
      <td>...</td>
      <td>12.20</td>
      <td>80.460000</td>
      <td>7.52</td>
      <td>17.210000</td>
      <td>3.014286</td>
      <td>28.942857</td>
      <td>9.371429</td>
      <td>35.0</td>
      <td>23.9</td>
      <td>5.8</td>
    </tr>
    <tr>
      <th>5</th>
      <td>sj</td>
      <td>1990</td>
      <td>23</td>
      <td>1990-06-04</td>
      <td>NaN</td>
      <td>0.174850</td>
      <td>0.254314</td>
      <td>0.181743</td>
      <td>9.58</td>
      <td>299.630000</td>
      <td>...</td>
      <td>26.49</td>
      <td>79.891429</td>
      <td>9.58</td>
      <td>17.212857</td>
      <td>2.100000</td>
      <td>28.114286</td>
      <td>6.942857</td>
      <td>34.4</td>
      <td>23.9</td>
      <td>39.1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>sj</td>
      <td>1990</td>
      <td>24</td>
      <td>1990-06-11</td>
      <td>0.112900</td>
      <td>0.092800</td>
      <td>0.205071</td>
      <td>0.210271</td>
      <td>3.48</td>
      <td>299.207143</td>
      <td>...</td>
      <td>38.60</td>
      <td>82.000000</td>
      <td>3.48</td>
      <td>17.234286</td>
      <td>2.042857</td>
      <td>27.414286</td>
      <td>6.771429</td>
      <td>32.2</td>
      <td>23.3</td>
      <td>29.7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>sj</td>
      <td>1990</td>
      <td>25</td>
      <td>1990-06-18</td>
      <td>0.072500</td>
      <td>0.072500</td>
      <td>0.151471</td>
      <td>0.133029</td>
      <td>151.12</td>
      <td>299.591429</td>
      <td>...</td>
      <td>30.00</td>
      <td>83.375714</td>
      <td>151.12</td>
      <td>17.977143</td>
      <td>1.571429</td>
      <td>28.371429</td>
      <td>7.685714</td>
      <td>33.9</td>
      <td>22.8</td>
      <td>21.1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>sj</td>
      <td>1990</td>
      <td>26</td>
      <td>1990-06-25</td>
      <td>0.102450</td>
      <td>0.146175</td>
      <td>0.125571</td>
      <td>0.123600</td>
      <td>19.32</td>
      <td>299.578571</td>
      <td>...</td>
      <td>37.51</td>
      <td>82.768571</td>
      <td>19.32</td>
      <td>17.790000</td>
      <td>1.885714</td>
      <td>28.328571</td>
      <td>7.385714</td>
      <td>33.9</td>
      <td>22.8</td>
      <td>21.1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>sj</td>
      <td>1990</td>
      <td>27</td>
      <td>1990-07-02</td>
      <td>NaN</td>
      <td>0.121550</td>
      <td>0.160683</td>
      <td>0.202567</td>
      <td>14.41</td>
      <td>300.154286</td>
      <td>...</td>
      <td>28.40</td>
      <td>81.281429</td>
      <td>14.41</td>
      <td>18.071429</td>
      <td>2.014286</td>
      <td>28.328571</td>
      <td>6.514286</td>
      <td>33.9</td>
      <td>24.4</td>
      <td>1.1</td>
    </tr>
    <tr>
      <th>10</th>
      <td>sj</td>
      <td>1990</td>
      <td>28</td>
      <td>1990-07-09</td>
      <td>0.192875</td>
      <td>0.082350</td>
      <td>0.191943</td>
      <td>0.152929</td>
      <td>22.27</td>
      <td>299.512857</td>
      <td>...</td>
      <td>43.72</td>
      <td>81.467143</td>
      <td>22.27</td>
      <td>17.418571</td>
      <td>2.157143</td>
      <td>27.557143</td>
      <td>7.157143</td>
      <td>31.7</td>
      <td>21.7</td>
      <td>63.7</td>
    </tr>
    <tr>
      <th>11</th>
      <td>sj</td>
      <td>1990</td>
      <td>29</td>
      <td>1990-07-16</td>
      <td>0.291600</td>
      <td>0.211800</td>
      <td>0.301200</td>
      <td>0.280667</td>
      <td>59.17</td>
      <td>299.667143</td>
      <td>...</td>
      <td>40.90</td>
      <td>82.144286</td>
      <td>59.17</td>
      <td>17.737143</td>
      <td>2.414286</td>
      <td>28.128571</td>
      <td>6.900000</td>
      <td>32.8</td>
      <td>23.9</td>
      <td>12.2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>sj</td>
      <td>1990</td>
      <td>30</td>
      <td>1990-07-23</td>
      <td>0.150567</td>
      <td>0.171700</td>
      <td>0.226900</td>
      <td>0.214557</td>
      <td>16.48</td>
      <td>299.558571</td>
      <td>...</td>
      <td>42.53</td>
      <td>80.742857</td>
      <td>16.48</td>
      <td>17.341429</td>
      <td>2.071429</td>
      <td>28.114286</td>
      <td>6.357143</td>
      <td>31.7</td>
      <td>22.8</td>
      <td>32.6</td>
    </tr>
    <tr>
      <th>13</th>
      <td>sj</td>
      <td>1990</td>
      <td>31</td>
      <td>1990-07-30</td>
      <td>NaN</td>
      <td>0.247150</td>
      <td>0.379700</td>
      <td>0.381357</td>
      <td>32.66</td>
      <td>299.862857</td>
      <td>...</td>
      <td>34.60</td>
      <td>80.584286</td>
      <td>32.66</td>
      <td>17.594286</td>
      <td>2.585714</td>
      <td>28.242857</td>
      <td>8.085714</td>
      <td>34.4</td>
      <td>22.8</td>
      <td>37.6</td>
    </tr>
    <tr>
      <th>14</th>
      <td>sj</td>
      <td>1990</td>
      <td>32</td>
      <td>1990-08-06</td>
      <td>NaN</td>
      <td>0.064333</td>
      <td>0.164443</td>
      <td>0.138857</td>
      <td>28.80</td>
      <td>300.391429</td>
      <td>...</td>
      <td>20.00</td>
      <td>79.650000</td>
      <td>28.80</td>
      <td>17.950000</td>
      <td>2.328571</td>
      <td>28.200000</td>
      <td>7.557143</td>
      <td>33.3</td>
      <td>23.3</td>
      <td>11.4</td>
    </tr>
    <tr>
      <th>15</th>
      <td>sj</td>
      <td>1990</td>
      <td>33</td>
      <td>1990-08-13</td>
      <td>NaN</td>
      <td>0.128033</td>
      <td>0.206957</td>
      <td>0.168243</td>
      <td>90.75</td>
      <td>299.958571</td>
      <td>...</td>
      <td>101.90</td>
      <td>84.178571</td>
      <td>90.75</td>
      <td>18.515714</td>
      <td>1.857143</td>
      <td>28.042857</td>
      <td>6.685714</td>
      <td>32.8</td>
      <td>22.8</td>
      <td>44.7</td>
    </tr>
    <tr>
      <th>16</th>
      <td>sj</td>
      <td>1990</td>
      <td>34</td>
      <td>1990-08-20</td>
      <td>0.190233</td>
      <td>0.168800</td>
      <td>0.167657</td>
      <td>0.172286</td>
      <td>32.40</td>
      <td>300.332857</td>
      <td>...</td>
      <td>25.90</td>
      <td>80.947143</td>
      <td>32.40</td>
      <td>18.174286</td>
      <td>2.485714</td>
      <td>28.342857</td>
      <td>7.014286</td>
      <td>33.3</td>
      <td>23.3</td>
      <td>5.4</td>
    </tr>
    <tr>
      <th>17</th>
      <td>sj</td>
      <td>1990</td>
      <td>35</td>
      <td>1990-08-27</td>
      <td>0.252900</td>
      <td>0.330750</td>
      <td>0.264171</td>
      <td>0.284314</td>
      <td>40.94</td>
      <td>300.118571</td>
      <td>...</td>
      <td>39.80</td>
      <td>83.348571</td>
      <td>40.94</td>
      <td>18.515714</td>
      <td>1.900000</td>
      <td>28.657143</td>
      <td>6.528571</td>
      <td>32.2</td>
      <td>24.4</td>
      <td>13.7</td>
    </tr>
    <tr>
      <th>18</th>
      <td>sj</td>
      <td>1990</td>
      <td>36</td>
      <td>1990-09-03</td>
      <td>0.235400</td>
      <td>0.200025</td>
      <td>0.283817</td>
      <td>0.230443</td>
      <td>28.86</td>
      <td>300.530000</td>
      <td>...</td>
      <td>30.40</td>
      <td>77.172857</td>
      <td>28.86</td>
      <td>17.560000</td>
      <td>3.471429</td>
      <td>28.328571</td>
      <td>7.614286</td>
      <td>32.8</td>
      <td>23.3</td>
      <td>14.2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>sj</td>
      <td>1990</td>
      <td>37</td>
      <td>1990-09-10</td>
      <td>0.127967</td>
      <td>0.437100</td>
      <td>0.123400</td>
      <td>0.148283</td>
      <td>64.56</td>
      <td>300.674286</td>
      <td>...</td>
      <td>24.18</td>
      <td>81.551429</td>
      <td>64.56</td>
      <td>18.777143</td>
      <td>2.900000</td>
      <td>28.685714</td>
      <td>8.057143</td>
      <td>33.9</td>
      <td>24.4</td>
      <td>25.9</td>
    </tr>
    <tr>
      <th>20</th>
      <td>sj</td>
      <td>1990</td>
      <td>38</td>
      <td>1990-09-17</td>
      <td>0.196350</td>
      <td>0.182433</td>
      <td>0.254829</td>
      <td>0.305686</td>
      <td>143.73</td>
      <td>299.857143</td>
      <td>...</td>
      <td>36.60</td>
      <td>81.637143</td>
      <td>143.73</td>
      <td>17.892857</td>
      <td>1.742857</td>
      <td>28.242857</td>
      <td>8.114286</td>
      <td>32.8</td>
      <td>23.9</td>
      <td>3.3</td>
    </tr>
    <tr>
      <th>21</th>
      <td>sj</td>
      <td>1990</td>
      <td>39</td>
      <td>1990-09-24</td>
      <td>0.116100</td>
      <td>0.260900</td>
      <td>0.199443</td>
      <td>0.244217</td>
      <td>51.39</td>
      <td>300.427143</td>
      <td>...</td>
      <td>16.40</td>
      <td>77.048571</td>
      <td>51.39</td>
      <td>17.468571</td>
      <td>2.257143</td>
      <td>28.342857</td>
      <td>7.728571</td>
      <td>32.8</td>
      <td>24.4</td>
      <td>15.8</td>
    </tr>
    <tr>
      <th>22</th>
      <td>sj</td>
      <td>1990</td>
      <td>40</td>
      <td>1990-10-01</td>
      <td>0.228550</td>
      <td>0.189750</td>
      <td>0.212486</td>
      <td>0.201186</td>
      <td>31.18</td>
      <td>300.775714</td>
      <td>...</td>
      <td>36.10</td>
      <td>78.520000</td>
      <td>31.18</td>
      <td>18.180000</td>
      <td>2.900000</td>
      <td>28.771429</td>
      <td>8.028571</td>
      <td>33.3</td>
      <td>23.9</td>
      <td>11.7</td>
    </tr>
    <tr>
      <th>23</th>
      <td>sj</td>
      <td>1990</td>
      <td>41</td>
      <td>1990-10-08</td>
      <td>0.171150</td>
      <td>0.067550</td>
      <td>0.179467</td>
      <td>0.157717</td>
      <td>51.42</td>
      <td>299.857143</td>
      <td>...</td>
      <td>132.40</td>
      <td>84.110000</td>
      <td>51.42</td>
      <td>18.512857</td>
      <td>2.571429</td>
      <td>28.628571</td>
      <td>7.314286</td>
      <td>33.3</td>
      <td>24.4</td>
      <td>57.7</td>
    </tr>
    <tr>
      <th>24</th>
      <td>sj</td>
      <td>1990</td>
      <td>42</td>
      <td>1990-10-15</td>
      <td>NaN</td>
      <td>0.070200</td>
      <td>0.181617</td>
      <td>0.165750</td>
      <td>143.55</td>
      <td>299.195714</td>
      <td>...</td>
      <td>279.60</td>
      <td>85.621429</td>
      <td>143.55</td>
      <td>18.115714</td>
      <td>1.871429</td>
      <td>27.628571</td>
      <td>7.400000</td>
      <td>32.8</td>
      <td>23.3</td>
      <td>61.8</td>
    </tr>
  </tbody>
</table>
<p>25 rows × 24 columns</p>
</div>



# Let's see the different columns and their datatypes


```python
print(train_df.dtypes)
```

    city                                      object
    year                                       int64
    weekofyear                                 int64
    week_start_date                           object
    ndvi_ne                                  float64
    ndvi_nw                                  float64
    ndvi_se                                  float64
    ndvi_sw                                  float64
    precipitation_amt_mm                     float64
    reanalysis_air_temp_k                    float64
    reanalysis_avg_temp_k                    float64
    reanalysis_dew_point_temp_k              float64
    reanalysis_max_air_temp_k                float64
    reanalysis_min_air_temp_k                float64
    reanalysis_precip_amt_kg_per_m2          float64
    reanalysis_relative_humidity_percent     float64
    reanalysis_sat_precip_amt_mm             float64
    reanalysis_specific_humidity_g_per_kg    float64
    reanalysis_tdtr_k                        float64
    station_avg_temp_c                       float64
    station_diur_temp_rng_c                  float64
    station_max_temp_c                       float64
    station_min_temp_c                       float64
    station_precip_mm                        float64
    dtype: object


# Going one column at a time

# 1. City
### - One-Hot-Encode

# 2. Year
### - Bin and Normalize (0-1 Interval) 

# 3. WeekOfYear
### - Normalize to 0-1 interval

# 4. Week_Start_Date
### - Drop Column 

# 5. NDVI_NE (vegetation index pixel northeast of the city centroid)
### - Correct Skew If Necessary and Drop N/As

# 6. NDVI_NW (vegetation index pixel northwest of the city centroid)
### - Correct Skew If Necessary and Drop N/As

# 7. NDVI_SE (vegetation index pixel southeast of the city centroid)
### - Correct Skew If Necessary and Drop N/As

# 8. NDVI_SW (vegetation index pixel southwest of the city centroid)
### - Correct Skew If Necessary and Drop N/As


# 9. Precipitation_Amt_mm thru to column Station_Precip_mm
### - Normalize to 0-1 interval, Correct Skew if Necessary and Drop N/As

# NOTE: We also identify and replace redundant columns


## We should aim to find a way to normalize date and combine the YEAR, WEEKOFYEAR, & WEEK_START_DATE columns
- I did this by creating equal sized bins for groups of years and keeping the continuous nature by compressing the categories between 0 and 1


```python
train_df['year'] = pd.to_numeric(pd.cut(train_df['year'], 11, labels=[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]))
test_df['year'] = pd.to_numeric(pd.cut(test_df['year'], 11, labels=[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]))
```


```python
# pandas drop a column with drop function to drop superflous week_start_date column
train_df = train_df.drop(['week_start_date'], axis=1)
test_df = test_df.drop(['week_start_date'], axis=1)
```

# One - Hot - Encode the cities column with pd.get_dummies
### It will look for any object dtypes and replace that column with the appropriate one-hot-encoded columns


```python
train_df = pd.get_dummies(train_df)
test_df = pd.get_dummies(test_df)
```

# Normalize & Check Distribution of WeekOfYear and Correct if Necessary 


```python
# It appears no correction is necessary as the data is fairly continuous around 28 (although there is a minor drop off in the final weeks)
# To accomodate the minor drop off I'll combine week 53 with week 52
sns.countplot(train_df['weekofyear'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f402a1bc588>




![png](output_15_1.png)



```python
train_df['weekofyear'] = train_df['weekofyear'].replace(53, 52)
test_df['weekofyear'] = test_df['weekofyear'].replace(53, 52)
print(train_df['weekofyear'].value_counts())
```

    52    28
    51    28
    24    28
    23    28
    22    28
    21    28
    20    28
    19    28
    18    28
    17    28
    16    28
    15    28
    14    28
    13    28
    12    28
    11    28
    10    28
    9     28
    8     28
    7     28
    6     28
    5     28
    4     28
    3     28
    2     28
    25    28
    26    28
    27    28
    40    28
    50    28
    49    28
    48    28
    47    28
    46    28
    45    28
    44    28
    43    28
    42    28
    41    28
    39    28
    28    28
    38    28
    37    28
    36    28
    35    28
    34    28
    33    28
    32    28
    31    28
    30    28
    29    28
    1     28
    Name: weekofyear, dtype: int64



```python
train_df['weekofyear']=train_df['weekofyear']/52
test_df['weekofyear']=test_df['weekofyear']/52
```


```python
print(train_df['weekofyear'].sample(5))
```

    332     0.730769
    1181    0.211538
    75      0.788462
    759     0.942308
    167     0.538462
    Name: weekofyear, dtype: float64


# Now that we've fixed a few columns we can look at our main problem...

### NaN values !!


```python
print(train_df.isna().sum())
```

    year                                       0
    weekofyear                                 0
    ndvi_ne                                  194
    ndvi_nw                                   52
    ndvi_se                                   22
    ndvi_sw                                   22
    precipitation_amt_mm                      13
    reanalysis_air_temp_k                     10
    reanalysis_avg_temp_k                     10
    reanalysis_dew_point_temp_k               10
    reanalysis_max_air_temp_k                 10
    reanalysis_min_air_temp_k                 10
    reanalysis_precip_amt_kg_per_m2           10
    reanalysis_relative_humidity_percent      10
    reanalysis_sat_precip_amt_mm              13
    reanalysis_specific_humidity_g_per_kg     10
    reanalysis_tdtr_k                         10
    station_avg_temp_c                        43
    station_diur_temp_rng_c                   43
    station_max_temp_c                        20
    station_min_temp_c                        14
    station_precip_mm                         22
    city_iq                                    0
    city_sj                                    0
    dtype: int64


Here we will first plot the Pearson correlation heatmap and see the correlation of independent variables with the output variable MEDV. We will only select features which has correlation of above 0.5 (taking absolute value) with the output variable.

The correlation coefficient has values between -1 to 1
- A value closer to 0 implies weaker correlation (exact 0 implying no correlation)
- A value closer to 1 implies stronger positive correlation
- A value closer to -1 implies stronger negative correlation


```python
#Using Pearson Correlation
plt.figure(figsize=(30,28))

sns.heatmap(train_df.corr(), annot=True, cmap=plt.cm.Reds)
plt.show()
```


![png](output_22_0.png)


## We can see right away that some of the features are essentially duplicates of each other and can be removed (i.e. reanalysis_sat_precip_amt_mm and precipitation_amt_mm)

#### We can also see that all of the ndvi features are related to each other. Let's use the correlatives to predict missing values
- ne_to_nw = 0.85
- ne_to_sw = 0.61
- ne_to_se = 0.67

- nw_to_sw = 0.65
- nw_to_se = 0.56

- se_to_sw = 0.82


```python
lr_nw_to_ne = LinearRegression()
lr_nw_to_ne.fit(train_df.dropna()['ndvi_nw'].values.reshape(-1,1), train_df.dropna()['ndvi_ne'])

lr_sw_to_ne = LinearRegression()
lr_sw_to_ne.fit(train_df.dropna()['ndvi_sw'].values.reshape(-1,1), train_df.dropna()['ndvi_ne'])

lr_se_to_ne = LinearRegression()
lr_se_to_ne.fit(train_df.dropna()['ndvi_se'].values.reshape(-1,1), train_df.dropna()['ndvi_ne'])

print("NE       =  NW * {:.3f} + {:.3f}".format(lr_nw_to_ne.coef_[0], abs(lr_nw_to_ne.intercept_)))
print("NE       =  SW * {:.3f} - {:.3f}".format(lr_sw_to_ne.coef_[0], abs(lr_sw_to_ne.intercept_)))
print("NE       =  SE * {:.3f} - {:.3f}".format(lr_se_to_ne.coef_[0], abs(lr_se_to_ne.intercept_)))
```

    NE       =  NW * 0.983 + 0.008
    NE       =  SW * 1.084 - 0.083
    NE       =  SE * 1.145 - 0.096



```python
lr_ne_to_nw = LinearRegression()
lr_ne_to_nw.fit(train_df.dropna()['ndvi_ne'].values.reshape(-1,1), train_df.dropna()['ndvi_nw'])

lr_sw_to_nw = LinearRegression()
lr_sw_to_nw.fit(train_df.dropna()['ndvi_sw'].values.reshape(-1,1), train_df.dropna()['ndvi_nw'])

lr_se_to_nw = LinearRegression()
lr_se_to_nw.fit(train_df.dropna()['ndvi_se'].values.reshape(-1,1), train_df.dropna()['ndvi_nw'])

print("NW       =  NE * {:.3f} + {:.3f}".format(lr_ne_to_nw.coef_[0], abs(lr_ne_to_nw.intercept_)))
print("NW       =  SW * {:.3f} - {:.3f}".format(lr_sw_to_nw.coef_[0], abs(lr_sw_to_nw.intercept_)))
print("NW       =  SE * {:.3f} - {:.3f}".format(lr_se_to_nw.coef_[0], abs(lr_se_to_nw.intercept_)))
```

    NW       =  NE * 0.730 + 0.032
    NW       =  SW * 0.933 - 0.058
    NW       =  SE * 0.920 - 0.055



```python
lr_ne_to_se = LinearRegression()
lr_ne_to_se.fit(train_df.dropna()['ndvi_ne'].values.reshape(-1,1), train_df.dropna()['ndvi_se'])

lr_sw_to_se = LinearRegression()
lr_sw_to_se.fit(train_df.dropna()['ndvi_sw'].values.reshape(-1,1), train_df.dropna()['ndvi_se'])

lr_nw_to_se = LinearRegression()
lr_nw_to_se.fit(train_df.dropna()['ndvi_nw'].values.reshape(-1,1), train_df.dropna()['ndvi_se'])

print("SE       =  NE * {:.3f} + {:.3f}".format(lr_ne_to_se.coef_[0], abs(lr_ne_to_se.intercept_)))
print("SE       =  SW * {:.3f} - {:.3f}".format(lr_sw_to_se.coef_[0], abs(lr_sw_to_se.intercept_)))
print("SE       =  NW * {:.3f} - {:.3f}".format(lr_nw_to_se.coef_[0], abs(lr_nw_to_se.intercept_)))
```

    SE       =  NE * 0.323 + 0.160
    SE       =  SW * 0.715 - 0.059
    SE       =  NW * 0.350 - 0.159



```python
lr_ne_to_sw = LinearRegression()
lr_ne_to_sw.fit(train_df.dropna()['ndvi_ne'].values.reshape(-1,1), train_df.dropna()['ndvi_sw'])

lr_se_to_sw = LinearRegression()
lr_se_to_sw.fit(train_df.dropna()['ndvi_se'].values.reshape(-1,1), train_df.dropna()['ndvi_sw'])

lr_nw_to_sw = LinearRegression()
lr_nw_to_sw.fit(train_df.dropna()['ndvi_nw'].values.reshape(-1,1), train_df.dropna()['ndvi_sw'])

print("SW       =  NE * {:.3f} + {:.3f}".format(lr_ne_to_sw.coef_[0], abs(lr_ne_to_sw.intercept_)))
print("SW       =  SE * {:.3f} - {:.3f}".format(lr_se_to_sw.coef_[0], abs(lr_se_to_sw.intercept_)))
print("SW       =  NW * {:.3f} - {:.3f}".format(lr_nw_to_sw.coef_[0], abs(lr_nw_to_sw.intercept_)))
```

    SW       =  NE * 0.404 + 0.149
    SW       =  SE * 0.943 - 0.012
    SW       =  NW * 0.468 - 0.143



```python
def missing_value(missing_quad, index):
    
    # Initialize correlative predictor values
    correlative_pred_1 = 0
    correlative_pred_2 = 0
    correlative_pred_3 = 0
    count = 0
    
    if missing_quad == "ne":
        if not np.isnan(train_df['ndvi_se'][index]):
            correlative_pred_1 = train_df['ndvi_se'][index]*lr_se_to_ne.coef_[0]+lr_se_to_ne.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_sw'][index]):
            correlative_pred_2 = train_df['ndvi_sw'][index]*lr_sw_to_ne.coef_[0]+lr_sw_to_ne.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_nw'][index]):
            correlative_pred_3 = train_df['ndvi_nw'][index]*lr_nw_to_ne.coef_[0]+lr_nw_to_ne.intercept_
            count += 5
        
        if count is not 0:
            correlative_mean = sum([correlative_pred_1*4, correlative_pred_2*4, correlative_pred_3*5])/count
        else:
            correlative_mean = np.nan
            
    elif missing_quad == "nw":
        
        if not np.isnan(train_df['ndvi_se'][index]):
            correlative_pred_1 = train_df['ndvi_se'][index]*lr_se_to_nw.coef_[0]+lr_se_to_nw.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_sw'][index]):
            correlative_pred_2 = train_df['ndvi_sw'][index]*lr_sw_to_nw.coef_[0]+lr_sw_to_nw.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_ne'][index]):
            correlative_pred_3 = train_df['ndvi_ne'][index]*lr_ne_to_nw.coef_[0]+lr_ne_to_nw.intercept_
            count += 5
        
        if count is not 0:
            correlative_mean = sum([correlative_pred_1*4, correlative_pred_2*4, correlative_pred_3*5])/count
        else:
            correlative_mean = np.nan
        
    elif missing_quad == "se":
        
        if not np.isnan(train_df['ndvi_nw'][index]):
            correlative_pred_1 = train_df['ndvi_nw'][index]*lr_nw_to_se.coef_[0]+lr_nw_to_se.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_sw'][index]):
            correlative_pred_2 = train_df['ndvi_sw'][index]*lr_sw_to_se.coef_[0]+lr_sw_to_se.intercept_
            count += 5
        if not np.isnan(train_df['ndvi_ne'][index]):
            correlative_pred_3 = train_df['ndvi_ne'][index]*lr_ne_to_se.coef_[0]+lr_ne_to_se.intercept_
            count += 4
        
        if count is not 0:
            correlative_mean = sum([correlative_pred_1*4, correlative_pred_2*5, correlative_pred_3*4])/count
        else:
            correlative_mean = np.nan
    else:
        
        if not np.isnan(train_df['ndvi_nw'][index]):
            correlative_pred_1 = train_df['ndvi_nw'][index]*lr_nw_to_sw.coef_[0]+lr_nw_to_sw.intercept_
            count += 4
        if not np.isnan(train_df['ndvi_se'][index]):
            correlative_pred_2 = train_df['ndvi_se'][index]*lr_se_to_sw.coef_[0]+lr_se_to_sw.intercept_
            count += 5
        if not np.isnan(train_df['ndvi_ne'][index]):
            correlative_pred_3 = train_df['ndvi_ne'][index]*lr_ne_to_sw.coef_[0]+lr_ne_to_sw.intercept_
            count += 4
        
        if count is not 0:
            correlative_mean = sum([correlative_pred_1*4, correlative_pred_2*5, correlative_pred_3*4])/count
        else:
            correlative_mean = np.nan
        
    return correlative_mean
```


```python
test_val = 17
print(train_df['ndvi_ne'][test_val], missing_value("ne", test_val))
```

    0.2529 0.26084389219673365



```python
for idx in range(0, len(train_df['ndvi_ne'])):
    
    if np.isnan(train_df['ndvi_ne'][idx]):
        train_df['ndvi_ne'][idx] = missing_value("ne", idx)
    
    if np.isnan(train_df['ndvi_nw'][idx]):
        train_df['ndvi_nw'][idx] = missing_value("nw", idx)
    
    if np.isnan(train_df['ndvi_sw'][idx]):
        train_df['ndvi_sw'][idx] = missing_value("sw", idx)
    
    if np.isnan(train_df['ndvi_se'][idx]):
        train_df['ndvi_se'][idx] = missing_value("se", idx)
        
for idx in range(0, len(test_df['ndvi_ne'])):
    
    if np.isnan(test_df['ndvi_ne'][idx]):
        test_df['ndvi_ne'][idx] = missing_value("ne", idx)
    
    if np.isnan(test_df['ndvi_nw'][idx]):
        test_df['ndvi_nw'][idx] = missing_value("nw", idx)
    
    if np.isnan(test_df['ndvi_sw'][idx]):
        test_df['ndvi_sw'][idx] = missing_value("sw", idx)
    
    if np.isnan(test_df['ndvi_se'][idx]):
        test_df['ndvi_se'][idx] = missing_value("se", idx)
```

    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      after removing the cwd from sys.path.
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:7: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      import sys
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:10: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      # Remove the CWD from sys.path while we load stuff.
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:13: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      del sys.path[0]
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:21: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:18: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:24: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/ipykernel_launcher.py:27: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy


## Now we go through and replace any further missing values with interpolated results of the values around them (for simplicity)


```python
train_df = train_df.interpolate(limit_direction='both')
test_df = test_df.interpolate(limit_direction='both')
```


```python
print(train_df.isna().sum())
```

    year                                     0
    weekofyear                               0
    ndvi_ne                                  0
    ndvi_nw                                  0
    ndvi_se                                  0
    ndvi_sw                                  0
    precipitation_amt_mm                     0
    reanalysis_air_temp_k                    0
    reanalysis_avg_temp_k                    0
    reanalysis_dew_point_temp_k              0
    reanalysis_max_air_temp_k                0
    reanalysis_min_air_temp_k                0
    reanalysis_precip_amt_kg_per_m2          0
    reanalysis_relative_humidity_percent     0
    reanalysis_sat_precip_amt_mm             0
    reanalysis_specific_humidity_g_per_kg    0
    reanalysis_tdtr_k                        0
    station_avg_temp_c                       0
    station_diur_temp_rng_c                  0
    station_max_temp_c                       0
    station_min_temp_c                       0
    station_precip_mm                        0
    city_iq                                  0
    city_sj                                  0
    dtype: int64


# From the correlation matrix we can see that a few variables have a correlation of 1... we can remove them


```python
train_df = train_df.drop(['reanalysis_sat_precip_amt_mm', 'reanalysis_specific_humidity_g_per_kg', 'city_iq'], axis=1)
test_df = test_df.drop(['reanalysis_sat_precip_amt_mm', 'reanalysis_specific_humidity_g_per_kg', 'city_iq'], axis=1)
```


```python
#Using Pearson Correlation
plt.figure(figsize=(30,28))

sns.heatmap(train_df.corr(), annot=True, cmap=plt.cm.Reds)
plt.show()
```


![png](output_36_0.png)


# <center>Time to perform mean normalization on every column

$$x^{'} = \frac{x - average(x)}{max(x)-min(x)}$$
- **where x is an original value**
- **where x' is the normalized value**


```python
# Define mean normalization function
def mean_norm_col(df_col):
    col_min = min(df_col)
    col_max = max(df_col)
    col_ave = sum(df_col)/len(df_col)
    
    col_norm = (df_col - col_ave)/(col_max-col_min)
    return col_norm
```


```python
for col in ['precipitation_amt_mm', 'reanalysis_air_temp_k', 'reanalysis_avg_temp_k', 'reanalysis_dew_point_temp_k', 
            'reanalysis_max_air_temp_k', 'reanalysis_min_air_temp_k', 'reanalysis_precip_amt_kg_per_m2', 
            'reanalysis_relative_humidity_percent', 'reanalysis_tdtr_k', 'station_avg_temp_c', 
            'station_diur_temp_rng_c', 'station_max_temp_c', 'station_min_temp_c', 'station_precip_mm']:
    train_df[col] = mean_norm_col(train_df[col])
    test_df[col] = mean_norm_col(test_df[col])
```


```python
print(train_df.sample(5))
```

          year  weekofyear   ndvi_ne   ndvi_nw   ndvi_se   ndvi_sw  \
    1326   0.9    0.019231  0.191471  0.155414  0.176014  0.187243   
    1118   0.7    0.019231  0.202571  0.198967  0.244557  0.187957   
    1328   0.9    0.057692  0.188229  0.220829  0.233243  0.169971   
    1042   0.6    0.557692  0.108043  0.072986  0.111229  0.117971   
    261    0.2    0.346154  0.133668  0.152100  0.214543  0.157971   
    
          precipitation_amt_mm  reanalysis_air_temp_k  reanalysis_avg_temp_k  \
    1326             -0.065930               0.076596               0.163519   
    1118              0.046782              -0.242007              -0.164926   
    1328              0.128694              -0.087710               0.031963   
    1042              0.044285              -0.298097              -0.184037   
    261              -0.063344               0.012007              -0.018703   
    
          reanalysis_dew_point_temp_k   ...     reanalysis_min_air_temp_k  \
    1326                    -0.065400   ...                     -0.124495   
    1118                     0.103943   ...                     -0.086034   
    1328                     0.209540   ...                     -0.255265   
    1042                    -0.217711   ...                     -0.393726   
    261                     -0.118279   ...                      0.121658   
    
          reanalysis_precip_amt_kg_per_m2  reanalysis_relative_humidity_percent  \
    1326                        -0.032823                             -0.085810   
    1118                         0.050595                              0.347666   
    1328                         0.041708                              0.313441   
    1042                        -0.055785                              0.061132   
    261                         -0.063147                             -0.149430   
    
          reanalysis_tdtr_k  station_avg_temp_c  station_diur_temp_rng_c  \
    1326           0.397231            0.116336                 0.308700   
    1118           0.019919            0.019705                 0.092076   
    1328           0.251175            0.026797                 0.121649   
    1042           0.427416           -0.189515                 0.080247   
    261           -0.133440            0.070364                 0.092921   
    
          station_max_temp_c  station_min_temp_c  station_precip_mm  city_sj  
    1326            0.229258           -0.054866           0.049490        0  
    1118            0.077645            0.023115           0.224715        0  
    1328            0.087323           -0.027343           0.158177        0  
    1042           -0.151387           -0.183307          -0.072450        0  
    261             0.126032            0.009354          -0.067297        1  
    
    [5 rows x 21 columns]


## Since the log function which will correct skew is not defined for negative values we will shift all the values by slightly more than the most negative number found in the sets (-0.68)


```python
for col in ['precipitation_amt_mm', 'reanalysis_air_temp_k', 'reanalysis_avg_temp_k', 'reanalysis_dew_point_temp_k', 
            'reanalysis_max_air_temp_k', 'reanalysis_min_air_temp_k', 'reanalysis_precip_amt_kg_per_m2', 
            'reanalysis_relative_humidity_percent', 'reanalysis_tdtr_k', 'station_avg_temp_c', 
            'station_diur_temp_rng_c', 'station_max_temp_c', 'station_min_temp_c', 'station_precip_mm', 'ndvi_ne',
            'ndvi_nw','ndvi_se','ndvi_sw']:
    train_df[col] = train_df[col]+abs(min(train_df[col]))+0.01
    test_df[col] = test_df[col]+abs(min(test_df[col]))+0.01
```

## So, when is the skewness too much?
#### The rule of thumb seems to be:

- If the skewness is between **-0.5 and 0.5**, the data is fairly symmetrical.
- If the skewness is between **-1 and -0.5(negatively skewed) or between 0.5 and 1(positively skewed)**, the data is moderately skewed.
- If the skewness is less than **-1(negatively skewed) or greater than 1(positively skewed)**, the data is highly skewed.

# Kurtosis
### Kurtosis is all about the tails of the distribution — not the peakedness or flatness.
### It is used to describe the extreme values in one versus the other tail. 

## It is actually the measure of **outliers** present in the distribution.

High kurtosis in a data set is an indicator that data has heavy tails or outliers. If there is a high kurtosis, then, we need to investigate why do we have so many outliers. It indicates a lot of things, maybe wrong data entry or other things. Investigate!
Low kurtosis in a data set is an indicator that data has light tails or lack of outliers. If we get low kurtosis(too good to be true), then also we need to investigate and trim the dataset of unwanted results.


- Mesokurtic: This distribution has kurtosis statistic similar to that of the normal distribution. It means that the extreme values of the distribution are similar to that of a normal distribution characteristic. 
    - This definition is used so that the standard normal distribution has a kurtosis of **3**.
- Leptokurtic (**Kurtosis > 3**): Distribution is longer, tails are fatter. Peak is higher and sharper than Mesokurtic, which means that data are heavy-tailed or profusion of outliers. 
    - Outliers stretch the horizontal axis of the histogram graph, which makes the bulk of the data appear in a narrow (“skinny”) vertical range, thereby giving the “skinniness” of a leptokurtic distribution.

- Platykurtic: (**Kurtosis < 3**): Distribution is shorter, tails are thinner than the normal distribution. The peak is lower and broader than Mesokurtic, which means that data are light-tailed or lack of outliers.
The reason for this is because the extreme values are less than that of the normal distribution.


```python
for col in train_df.columns:
    sns.distplot(train_df[col]).set_title("Skew : {:.3f}   ---   Kurtosis : {:.3f}   ---   Series : {}".format(train_df[col].skew(), train_df[col].kurt(),col))
    plt.show()
    
    if abs(train_df[col].skew()) > 0.25:
        sns.distplot(np.sqrt(train_df[col])).set_title("CORRECTED\nSkew : {:.3f}   ---   Kurtosis : {:.3f}   ---   Series : {}".format(np.exp(train_df[col]).skew(), np.exp(train_df[col]).kurt(),col))
        plt.show()
```

    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_1.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_3.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_5.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_7.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_9.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_11.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_13.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_15.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_17.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_19.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_21.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_23.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_25.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_27.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_29.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_31.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_33.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_35.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_37.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_39.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_41.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_43.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_45.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_47.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_49.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_51.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_53.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_55.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_57.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_59.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_61.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_63.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_65.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_67.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_69.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_71.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_45_73.png)



```python
to_be_log = ['reanalysis_max_air_temp_k', 'reanalysis_precip_amt_kg_per_m2', 
                'reanalysis_tdtr_k', 'station_precip_mm']
to_be_sqrt = ['ndvi_se', 'ndvi_sw', 'reanalysis_relative_humidity_percent', 'station_diur_temp_rng_c', 'precipitation_amt_mm']
```


```python
for col in train_df.columns:
    if col in to_be_log:
        train_df[col] = np.log(train_df[col])
        test_df[col] = np.log(test_df[col])
    elif col in to_be_sqrt:
        train_df[col] = np.sqrt(train_df[col])
        test_df[col] = np.sqrt(test_df[col])
    else:
        pass
```


```python
for col in train_df.columns:
    print("Skew : {:.3f}   ---   Kurtosis : {:.3f}   ---   Series : {}".format(train_df[col].skew(), train_df[col].kurt(),col))
```

    Skew : -0.418   ---   Kurtosis : -0.977   ---   Series : year
    Skew : 0.000   ---   Kurtosis : -1.201   ---   Series : weekofyear
    Skew : -0.011   ---   Kurtosis : 0.067   ---   Series : ndvi_ne
    Skew : 0.022   ---   Kurtosis : 0.100   ---   Series : ndvi_nw
    Skew : 0.016   ---   Kurtosis : 0.467   ---   Series : ndvi_se
    Skew : 0.230   ---   Kurtosis : 0.658   ---   Series : ndvi_sw
    Skew : 0.285   ---   Kurtosis : -0.254   ---   Series : precipitation_amt_mm
    Skew : -0.075   ---   Kurtosis : -0.677   ---   Series : reanalysis_air_temp_k
    Skew : -0.185   ---   Kurtosis : -0.531   ---   Series : reanalysis_avg_temp_k
    Skew : -0.718   ---   Kurtosis : -0.114   ---   Series : reanalysis_dew_point_temp_k
    Skew : -0.333   ---   Kurtosis : 0.430   ---   Series : reanalysis_max_air_temp_k
    Skew : -0.673   ---   Kurtosis : -0.201   ---   Series : reanalysis_min_air_temp_k
    Skew : 0.096   ---   Kurtosis : -0.305   ---   Series : reanalysis_precip_amt_kg_per_m2
    Skew : 0.131   ---   Kurtosis : 0.554   ---   Series : reanalysis_relative_humidity_percent
    Skew : 0.352   ---   Kurtosis : -1.206   ---   Series : reanalysis_tdtr_k
    Skew : -0.562   ---   Kurtosis : -0.125   ---   Series : station_avg_temp_c
    Skew : 0.286   ---   Kurtosis : -0.556   ---   Series : station_diur_temp_rng_c
    Skew : -0.259   ---   Kurtosis : 0.203   ---   Series : station_max_temp_c
    Skew : -0.304   ---   Kurtosis : 0.228   ---   Series : station_min_temp_c
    Skew : 0.092   ---   Kurtosis : -0.664   ---   Series : station_precip_mm
    Skew : -0.597   ---   Kurtosis : -1.646   ---   Series : city_sj


# At this point we have done most of the required data cleaning
## Let's take a look at the type of modelling that will work best based on the requirements

### REQUIREMENTS
1. Predict the number of dengue fever cases reported each week in San Juan, Puerto Rico and Iquitos, Peru?
2. The prediction values range from 0 to 461 with a strong mean around 25

**Since the prediction values given with the training data are not standardized... we will scale them**<br>
**To avoid addional confusion we will not normalize them past applying sqrt...**


```python
sns.distplot(train_label)
plt.show()
sns.distplot(np.sqrt(train_label/461)).set_title("CORRECTED WITH SQRT")
plt.show()
```

    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_50_1.png)


    /home/ec2-user/anaconda3/envs/tensorflow_p36/lib/python3.6/site-packages/matplotlib/axes/_axes.py:6462: UserWarning: The 'normed' kwarg is deprecated, and has been replaced by the 'density' kwarg.
      warnings.warn("The 'normed' kwarg is deprecated, and has been "



![png](output_50_3.png)



```python
train_label = np.sqrt(train_label/461)
```

# Alright Model Time!
### Lets split the training set into training and validation


```python
X_train, X_val, Y_train, Y_val = train_test_split(train_df, train_label, test_size=0.1)
```


```python
print(X_train.describe())
print(X_val.describe())
print(Y_train.describe())
print(Y_val.describe())
```

                  year   weekofyear      ndvi_ne      ndvi_nw      ndvi_se  \
    count  1310.000000  1310.000000  1310.000000  1310.000000  1310.000000   
    mean      0.555038     0.511759     0.552863     0.594592     0.471578   
    std       0.292694     0.288882     0.132626     0.119103     0.077714   
    min       0.000000     0.019231     0.010000     0.010000     0.100000   
    25%       0.300000     0.269231     0.463717     0.515800     0.422460   
    50%       0.600000     0.519231     0.534942     0.582981     0.469167   
    75%       0.800000     0.769231     0.645958     0.678275     0.522632   
    max       1.000000     1.000000     0.924607     0.920529     0.750898   
    
               ndvi_sw  precipitation_amt_mm  reanalysis_air_temp_k  \
    count  1310.000000           1310.000000            1310.000000   
    mean      0.518754              0.319596               0.548618   
    std       0.078853              0.156403               0.179992   
    min       0.100000              0.100000               0.010000   
    25%       0.465917              0.185537               0.408820   
    50%       0.513399              0.327037               0.541350   
    75%       0.564709              0.436057               0.697724   
    max       0.787067              1.003713               1.010000   
    
           reanalysis_avg_temp_k  reanalysis_dew_point_temp_k     ...       \
    count            1310.000000                  1310.000000     ...        
    mean                0.548854                     0.648093     ...        
    std                 0.156947                     0.171782     ...        
    min                 0.010000                     0.010000     ...        
    25%                 0.427778                     0.520462     ...        
    50%                 0.558000                     0.691427     ...        
    75%                 0.671333                     0.784169     ...        
    max                 1.010000                     1.010000     ...        
    
           reanalysis_min_air_temp_k  reanalysis_precip_amt_kg_per_m2  \
    count                1310.000000                      1310.000000   
    mean                    0.690658                        -2.841731   
    std                     0.196551                         0.803061   
    min                     0.010000                        -4.605170   
    25%                     0.548462                        -3.413461   
    50%                     0.729231                        -2.846829   
    75%                     0.856154                        -2.268256   
    max                     1.010000                         0.009950   
    
           reanalysis_relative_humidity_percent  reanalysis_tdtr_k  \
    count                           1310.000000        1310.000000   
    mean                               0.771537          -1.853225   
    std                                0.111613           0.952855   
    min                                0.100000          -4.605170   
    25%                                0.697572          -2.574233   
    50%                                0.749341          -2.204623   
    75%                                0.842537          -0.856710   
    max                                1.004988           0.009950   
    
           station_avg_temp_c  station_diur_temp_rng_c  station_max_temp_c  \
    count         1310.000000              1310.000000         1310.000000   
    mean             0.626621                 0.544920            0.380039   
    std              0.135513                 0.161944            0.126062   
    min              0.163495                 0.100000            0.010000   
    25%              0.534316                 0.432943            0.293871   
    50%              0.650122                 0.506472            0.403548   
    75%              0.727325                 0.674908            0.474516   
    max              1.010000                 1.004988            1.010000   
    
           station_min_temp_c  station_precip_mm      city_sj  
    count         1310.000000        1310.000000  1310.000000  
    mean             0.691280          -2.921523     0.648855  
    std              0.143774           0.937775     0.477510  
    min              0.010000          -4.605170     0.000000  
    25%              0.597156          -3.649149     0.000000  
    50%              0.698073          -2.920656     1.000000  
    75%              0.798991          -2.214496     1.000000  
    max              1.010000           0.009950     1.000000  
    
    [8 rows x 21 columns]
                 year  weekofyear     ndvi_ne     ndvi_nw     ndvi_se     ndvi_sw  \
    count  146.000000  146.000000  146.000000  146.000000  146.000000  146.000000   
    mean     0.591781    0.490385    0.552043    0.597445    0.474597    0.520235   
    std      0.286599    0.287538    0.142721    0.115977    0.075109    0.075670   
    min      0.000000    0.019231    0.126050    0.342400    0.277513    0.335992   
    25%      0.400000    0.250000    0.465092    0.515725    0.438235    0.473703   
    50%      0.700000    0.500000    0.551383    0.596461    0.481617    0.513684   
    75%      0.800000    0.725962    0.658571    0.680754    0.521654    0.567969   
    max      1.000000    1.000000    0.873083    0.899114    0.680035    0.734293   
    
           precipitation_amt_mm  reanalysis_air_temp_k  reanalysis_avg_temp_k  \
    count            146.000000             146.000000             146.000000   
    mean               0.325471               0.532506               0.547352   
    std                0.158154               0.177779               0.156490   
    min                0.100000               0.037762               0.146889   
    25%                0.201633               0.410850               0.441667   
    50%                0.333832               0.525392               0.543778   
    75%                0.421642               0.663399               0.674000   
    max                1.004988               0.912927               0.916667   
    
           reanalysis_dew_point_temp_k     ...      reanalysis_min_air_temp_k  \
    count                   146.000000     ...                     146.000000   
    mean                      0.627624     ...                       0.667561   
    std                       0.185641     ...                       0.198957   
    min                       0.103593     ...                       0.056154   
    25%                       0.498281     ...                       0.511923   
    50%                       0.674071     ...                       0.690769   
    75%                       0.782019     ...                       0.840769   
    max                       0.977234     ...                       0.971538   
    
           reanalysis_precip_amt_kg_per_m2  reanalysis_relative_humidity_percent  \
    count                       146.000000                            146.000000   
    mean                         -2.863018                              0.768960   
    std                           0.757533                              0.113712   
    min                          -4.605170                              0.282699   
    25%                          -3.397611                              0.691505   
    50%                          -2.900504                              0.745876   
    75%                          -2.443531                              0.848049   
    max                          -0.609215                              0.989176   
    
           reanalysis_tdtr_k  station_avg_temp_c  station_diur_temp_rng_c  \
    count         146.000000          146.000000               146.000000   
    mean           -1.717689            0.610919                 0.571844   
    std             0.994654            0.142772                 0.171439   
    min            -3.316208            0.010000                 0.154731   
    25%            -2.549001            0.523678                 0.433673   
    50%            -2.030890            0.639749                 0.535658   
    75%            -0.671439            0.718587                 0.732558   
    max            -0.133927            0.853465                 0.890799   
    
           station_max_temp_c  station_min_temp_c  station_precip_mm     city_sj  
    count          146.000000          146.000000         146.000000  146.000000  
    mean             0.387044            0.665743          -2.945710    0.589041  
    std              0.129599            0.145326           0.888039    0.493701  
    min              0.010000            0.230183          -4.605170    0.000000  
    25%              0.293871            0.570780          -3.610989    0.000000  
    50%              0.403548            0.652202          -2.824676    1.000000  
    75%              0.480968            0.753119          -2.217463    1.000000  
    max              0.674516            1.010000          -1.180369    1.000000  
    
    [8 rows x 21 columns]
    count    1310.000000
    mean        0.008708
    std         0.006314
    min         0.000000
    25%         0.004850
    50%         0.007514
    75%         0.011478
    max         0.046575
    Name: total_cases, dtype: float64
    count    146.000000
    mean       0.008508
    std        0.006932
    min        0.000000
    25%        0.004338
    50%        0.006684
    75%        0.011165
    max        0.042341
    Name: total_cases, dtype: float64



```python
# Fit regression model
model = GradientBoostingRegressor(n_estimators=500, max_depth=100, learning_rate=0.001, loss='ls', criterion='mae')
print(model.fit(X_train, Y_train))
print(model.score(X_val, Y_val))
```

    GradientBoostingRegressor(alpha=0.9, criterion='mae', init=None,
                 learning_rate=0.001, loss='ls', max_depth=100,
                 max_features=None, max_leaf_nodes=None,
                 min_impurity_decrease=0.0, min_impurity_split=None,
                 min_samples_leaf=1, min_samples_split=2,
                 min_weight_fraction_leaf=0.0, n_estimators=500,
                 n_iter_no_change=None, presort='auto', random_state=None,
                 subsample=1.0, tol=0.0001, validation_fraction=0.1, verbose=0,
                 warm_start=False)
    0.34485530260671504



```python
Y = model.predict(X_val)
print(mean_absolute_error((Y_val*461)**2, (Y*461)**2))
print(mean_absolute_error((Y_val*461)**2, (Y_2*461)**2))
```

    18.396442168142606
    15.494817047494731



```python
# define base model
def baselineModel():
    # create model
    model = Sequential()
    
    model.add(Dense(128, input_dim=21, activation='relu'))
    
    model.add(Dense(128, activation='relu'))
    model.add(Dense(128, activation='linear'))
    
    model.add(Dense(1))
    
    adam = keras.optimizers.Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    
    # Compile model
    model.compile(loss='mean_squared_error', optimizer=adam, metrics=['mae'])
    return model

# define intermediate model
def intermediateModel():
    # create model
    model = Sequential()
    model.add(Dense(256, input_dim=21, activation='relu'))
    model.add(Dropout(0.02))

    model.add(Dense(192, activation='relu'))
    model.add(Dropout(0.02))
    model.add(Dense(192, activation='relu'))
    model.add(Dropout(0.02))
    model.add(Dense(192, activation='relu'))
    model.add(Dropout(0.02))
    
    model.add(Dense(128, activation='linear'))
    
    model.add(Dense(1))
    
    adam = keras.optimizers.Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    
    # Compile model
    model.compile(loss='mean_squared_error', optimizer=adam, metrics=['mae'])
    return model

# define intermediate model
def advancedModel():
    # create model
    model = Sequential()
    model.add(Dense(1028, input_dim=21, activation='relu'))
    model.add(Dropout(0.2))

    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.1))
    
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.1))
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.1))
    
    model.add(Dense(128, activation='relu'))
    
    model.add(Dense(1))
    
    adam = keras.optimizers.Adam(lr=0.0005, beta_1=0.9, beta_2=0.999, decay=0.0)
    
    # Compile model
    model.compile(loss='mean_squared_error', optimizer=adam, metrics=['mae'])
    return model
```


```python
advanced_model = advancedModel()
```


```python
intermediate_model = intermediateModel()
```


```python
baseline_model = baselineModel()
```


```python
history_advanced = advanced_model.fit(X_train, Y_train, batch_size=16, epochs=200, validation_data=(X_val, Y_val))
```

    Train on 1310 samples, validate on 146 samples
    Epoch 1/200
    1310/1310 [==============================] - 4s 3ms/step - loss: 7.9402e-04 - mean_absolute_error: 0.0146 - val_loss: 4.4616e-05 - val_mean_absolute_error: 0.0043
    Epoch 2/200
    1310/1310 [==============================] - 0s 367us/step - loss: 6.4502e-05 - mean_absolute_error: 0.0061 - val_loss: 4.0831e-05 - val_mean_absolute_error: 0.0043
    Epoch 3/200
    1310/1310 [==============================] - 0s 371us/step - loss: 4.7458e-05 - mean_absolute_error: 0.0050 - val_loss: 3.9120e-05 - val_mean_absolute_error: 0.0041
    Epoch 4/200
    1310/1310 [==============================] - 0s 369us/step - loss: 4.4476e-05 - mean_absolute_error: 0.0049 - val_loss: 4.1952e-05 - val_mean_absolute_error: 0.0041
    Epoch 5/200
    1310/1310 [==============================] - 0s 369us/step - loss: 4.0077e-05 - mean_absolute_error: 0.0046 - val_loss: 3.9175e-05 - val_mean_absolute_error: 0.0040
    Epoch 6/200
    1310/1310 [==============================] - 0s 369us/step - loss: 3.9020e-05 - mean_absolute_error: 0.0045 - val_loss: 4.7979e-05 - val_mean_absolute_error: 0.0043
    Epoch 7/200
    1310/1310 [==============================] - 0s 372us/step - loss: 3.9941e-05 - mean_absolute_error: 0.0045 - val_loss: 4.8070e-05 - val_mean_absolute_error: 0.0044
    Epoch 8/200
    1310/1310 [==============================] - 0s 369us/step - loss: 3.5560e-05 - mean_absolute_error: 0.0043 - val_loss: 4.4238e-05 - val_mean_absolute_error: 0.0043
    Epoch 9/200
    1310/1310 [==============================] - 0s 371us/step - loss: 3.4343e-05 - mean_absolute_error: 0.0042 - val_loss: 3.6466e-05 - val_mean_absolute_error: 0.0039
    Epoch 10/200
    1310/1310 [==============================] - 0s 368us/step - loss: 3.3957e-05 - mean_absolute_error: 0.0042 - val_loss: 3.7586e-05 - val_mean_absolute_error: 0.0039
    Epoch 11/200
    1310/1310 [==============================] - 0s 369us/step - loss: 3.3644e-05 - mean_absolute_error: 0.0041 - val_loss: 4.3540e-05 - val_mean_absolute_error: 0.0042
    Epoch 12/200
    1310/1310 [==============================] - 0s 367us/step - loss: 3.2918e-05 - mean_absolute_error: 0.0041 - val_loss: 3.9847e-05 - val_mean_absolute_error: 0.0041
    Epoch 13/200
    1310/1310 [==============================] - 0s 369us/step - loss: 3.4067e-05 - mean_absolute_error: 0.0042 - val_loss: 3.5217e-05 - val_mean_absolute_error: 0.0038
    Epoch 14/200
    1310/1310 [==============================] - 0s 368us/step - loss: 3.2413e-05 - mean_absolute_error: 0.0041 - val_loss: 3.1304e-05 - val_mean_absolute_error: 0.0038
    Epoch 15/200
    1310/1310 [==============================] - 0s 368us/step - loss: 3.3003e-05 - mean_absolute_error: 0.0041 - val_loss: 3.1336e-05 - val_mean_absolute_error: 0.0038
    Epoch 16/200
    1310/1310 [==============================] - 0s 372us/step - loss: 3.1672e-05 - mean_absolute_error: 0.0040 - val_loss: 4.4861e-05 - val_mean_absolute_error: 0.0043
    Epoch 17/200
    1310/1310 [==============================] - 0s 370us/step - loss: 3.1327e-05 - mean_absolute_error: 0.0040 - val_loss: 3.4157e-05 - val_mean_absolute_error: 0.0038
    Epoch 18/200
    1310/1310 [==============================] - 0s 370us/step - loss: 3.1358e-05 - mean_absolute_error: 0.0039 - val_loss: 3.3125e-05 - val_mean_absolute_error: 0.0037
    Epoch 19/200
    1310/1310 [==============================] - 0s 367us/step - loss: 3.1880e-05 - mean_absolute_error: 0.0040 - val_loss: 3.7815e-05 - val_mean_absolute_error: 0.0039
    Epoch 20/200
    1310/1310 [==============================] - 0s 368us/step - loss: 3.0986e-05 - mean_absolute_error: 0.0039 - val_loss: 3.6027e-05 - val_mean_absolute_error: 0.0039
    Epoch 21/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.9585e-05 - mean_absolute_error: 0.0038 - val_loss: 3.5169e-05 - val_mean_absolute_error: 0.0038
    Epoch 22/200
    1310/1310 [==============================] - 0s 368us/step - loss: 3.0103e-05 - mean_absolute_error: 0.0039 - val_loss: 3.7986e-05 - val_mean_absolute_error: 0.0039
    Epoch 23/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.9982e-05 - mean_absolute_error: 0.0039 - val_loss: 3.3861e-05 - val_mean_absolute_error: 0.0037
    Epoch 24/200
    1310/1310 [==============================] - 0s 369us/step - loss: 3.0356e-05 - mean_absolute_error: 0.0039 - val_loss: 2.8579e-05 - val_mean_absolute_error: 0.0036
    Epoch 25/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.9727e-05 - mean_absolute_error: 0.0038 - val_loss: 2.8950e-05 - val_mean_absolute_error: 0.0037
    Epoch 26/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.9059e-05 - mean_absolute_error: 0.0038 - val_loss: 3.0137e-05 - val_mean_absolute_error: 0.0036
    Epoch 27/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.9171e-05 - mean_absolute_error: 0.0038 - val_loss: 3.3875e-05 - val_mean_absolute_error: 0.0037
    Epoch 28/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.9388e-05 - mean_absolute_error: 0.0038 - val_loss: 3.8611e-05 - val_mean_absolute_error: 0.0040
    Epoch 29/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.9082e-05 - mean_absolute_error: 0.0038 - val_loss: 3.1170e-05 - val_mean_absolute_error: 0.0036
    Epoch 30/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.9472e-05 - mean_absolute_error: 0.0039 - val_loss: 2.8087e-05 - val_mean_absolute_error: 0.0037
    Epoch 31/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.8503e-05 - mean_absolute_error: 0.0037 - val_loss: 3.2690e-05 - val_mean_absolute_error: 0.0037
    Epoch 32/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.8665e-05 - mean_absolute_error: 0.0038 - val_loss: 3.3647e-05 - val_mean_absolute_error: 0.0037
    Epoch 33/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.8196e-05 - mean_absolute_error: 0.0037 - val_loss: 3.0533e-05 - val_mean_absolute_error: 0.0036
    Epoch 34/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.8225e-05 - mean_absolute_error: 0.0038 - val_loss: 3.6011e-05 - val_mean_absolute_error: 0.0038
    Epoch 35/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.7620e-05 - mean_absolute_error: 0.0037 - val_loss: 3.2542e-05 - val_mean_absolute_error: 0.0036
    Epoch 36/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.8721e-05 - mean_absolute_error: 0.0038 - val_loss: 3.0426e-05 - val_mean_absolute_error: 0.0036
    Epoch 37/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.8655e-05 - mean_absolute_error: 0.0038 - val_loss: 2.9357e-05 - val_mean_absolute_error: 0.0037
    Epoch 38/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.7234e-05 - mean_absolute_error: 0.0037 - val_loss: 3.2697e-05 - val_mean_absolute_error: 0.0037
    Epoch 39/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.8845e-05 - mean_absolute_error: 0.0038 - val_loss: 2.9042e-05 - val_mean_absolute_error: 0.0036
    Epoch 40/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.8346e-05 - mean_absolute_error: 0.0038 - val_loss: 2.7404e-05 - val_mean_absolute_error: 0.0036
    Epoch 41/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.7933e-05 - mean_absolute_error: 0.0037 - val_loss: 2.8402e-05 - val_mean_absolute_error: 0.0036
    Epoch 42/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.6068e-05 - mean_absolute_error: 0.0036 - val_loss: 2.8463e-05 - val_mean_absolute_error: 0.0035
    Epoch 43/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.7440e-05 - mean_absolute_error: 0.0037 - val_loss: 2.7383e-05 - val_mean_absolute_error: 0.0035
    Epoch 44/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.6741e-05 - mean_absolute_error: 0.0037 - val_loss: 2.9200e-05 - val_mean_absolute_error: 0.0040
    Epoch 45/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.8379e-05 - mean_absolute_error: 0.0037 - val_loss: 2.8777e-05 - val_mean_absolute_error: 0.0041
    Epoch 46/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.7440e-05 - mean_absolute_error: 0.0037 - val_loss: 4.0598e-05 - val_mean_absolute_error: 0.0042
    Epoch 47/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.6711e-05 - mean_absolute_error: 0.0036 - val_loss: 3.2179e-05 - val_mean_absolute_error: 0.0036
    Epoch 48/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.6102e-05 - mean_absolute_error: 0.0036 - val_loss: 2.5639e-05 - val_mean_absolute_error: 0.0034
    Epoch 49/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.5668e-05 - mean_absolute_error: 0.0036 - val_loss: 3.3261e-05 - val_mean_absolute_error: 0.0037
    Epoch 50/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.5864e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8942e-05 - val_mean_absolute_error: 0.0035
    Epoch 51/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.7190e-05 - mean_absolute_error: 0.0037 - val_loss: 3.2294e-05 - val_mean_absolute_error: 0.0036
    Epoch 52/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.5457e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8983e-05 - val_mean_absolute_error: 0.0034
    Epoch 53/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.5523e-05 - mean_absolute_error: 0.0035 - val_loss: 2.5128e-05 - val_mean_absolute_error: 0.0033
    Epoch 54/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.5038e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8161e-05 - val_mean_absolute_error: 0.0034
    Epoch 55/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.5636e-05 - mean_absolute_error: 0.0035 - val_loss: 2.5332e-05 - val_mean_absolute_error: 0.0035
    Epoch 56/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.5275e-05 - mean_absolute_error: 0.0035 - val_loss: 2.7887e-05 - val_mean_absolute_error: 0.0034
    Epoch 57/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.5928e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8832e-05 - val_mean_absolute_error: 0.0036
    Epoch 58/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.6899e-05 - mean_absolute_error: 0.0037 - val_loss: 2.6810e-05 - val_mean_absolute_error: 0.0033
    Epoch 59/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.5001e-05 - mean_absolute_error: 0.0035 - val_loss: 2.7587e-05 - val_mean_absolute_error: 0.0034
    Epoch 60/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.4647e-05 - mean_absolute_error: 0.0035 - val_loss: 2.6614e-05 - val_mean_absolute_error: 0.0034
    Epoch 61/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.6235e-05 - mean_absolute_error: 0.0036 - val_loss: 2.7661e-05 - val_mean_absolute_error: 0.0034
    Epoch 62/200
    1310/1310 [==============================] - 0s 365us/step - loss: 2.4776e-05 - mean_absolute_error: 0.0035 - val_loss: 2.6394e-05 - val_mean_absolute_error: 0.0033
    Epoch 63/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.4748e-05 - mean_absolute_error: 0.0035 - val_loss: 3.2357e-05 - val_mean_absolute_error: 0.0036
    Epoch 64/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.5364e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8983e-05 - val_mean_absolute_error: 0.0035
    Epoch 65/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.5053e-05 - mean_absolute_error: 0.0034 - val_loss: 2.8142e-05 - val_mean_absolute_error: 0.0034
    Epoch 66/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.3933e-05 - mean_absolute_error: 0.0034 - val_loss: 2.4834e-05 - val_mean_absolute_error: 0.0035
    Epoch 67/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.5076e-05 - mean_absolute_error: 0.0035 - val_loss: 3.1852e-05 - val_mean_absolute_error: 0.0037
    Epoch 68/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.5837e-05 - mean_absolute_error: 0.0035 - val_loss: 2.6191e-05 - val_mean_absolute_error: 0.0033
    Epoch 69/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.3858e-05 - mean_absolute_error: 0.0034 - val_loss: 2.6699e-05 - val_mean_absolute_error: 0.0037
    Epoch 70/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.4316e-05 - mean_absolute_error: 0.0035 - val_loss: 2.6904e-05 - val_mean_absolute_error: 0.0035
    Epoch 71/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.3298e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3793e-05 - val_mean_absolute_error: 0.0034
    Epoch 72/200
    1310/1310 [==============================] - 1s 382us/step - loss: 2.4870e-05 - mean_absolute_error: 0.0035 - val_loss: 2.8624e-05 - val_mean_absolute_error: 0.0035
    Epoch 73/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.3783e-05 - mean_absolute_error: 0.0034 - val_loss: 3.2592e-05 - val_mean_absolute_error: 0.0037
    Epoch 74/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.4637e-05 - mean_absolute_error: 0.0035 - val_loss: 2.6726e-05 - val_mean_absolute_error: 0.0034
    Epoch 75/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.3476e-05 - mean_absolute_error: 0.0034 - val_loss: 2.4956e-05 - val_mean_absolute_error: 0.0034
    Epoch 76/200
    1310/1310 [==============================] - 1s 384us/step - loss: 2.4275e-05 - mean_absolute_error: 0.0034 - val_loss: 2.5581e-05 - val_mean_absolute_error: 0.0037
    Epoch 77/200
    1310/1310 [==============================] - 0s 380us/step - loss: 2.4113e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3495e-05 - val_mean_absolute_error: 0.0034
    Epoch 78/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.5201e-05 - mean_absolute_error: 0.0035 - val_loss: 2.3580e-05 - val_mean_absolute_error: 0.0034
    Epoch 79/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.3256e-05 - mean_absolute_error: 0.0034 - val_loss: 2.7552e-05 - val_mean_absolute_error: 0.0034
    Epoch 80/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.4734e-05 - mean_absolute_error: 0.0034 - val_loss: 2.6038e-05 - val_mean_absolute_error: 0.0035
    Epoch 81/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.5031e-05 - mean_absolute_error: 0.0035 - val_loss: 2.2960e-05 - val_mean_absolute_error: 0.0033
    Epoch 82/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2514e-05 - mean_absolute_error: 0.0033 - val_loss: 2.7761e-05 - val_mean_absolute_error: 0.0034
    Epoch 83/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.4307e-05 - mean_absolute_error: 0.0035 - val_loss: 2.4043e-05 - val_mean_absolute_error: 0.0034
    Epoch 84/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.3117e-05 - mean_absolute_error: 0.0034 - val_loss: 2.6199e-05 - val_mean_absolute_error: 0.0033
    Epoch 85/200
    1310/1310 [==============================] - 0s 366us/step - loss: 2.4986e-05 - mean_absolute_error: 0.0035 - val_loss: 2.4469e-05 - val_mean_absolute_error: 0.0033
    Epoch 86/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.3295e-05 - mean_absolute_error: 0.0034 - val_loss: 2.4740e-05 - val_mean_absolute_error: 0.0033
    Epoch 87/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.3699e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3309e-05 - val_mean_absolute_error: 0.0034
    Epoch 88/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.3491e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3886e-05 - val_mean_absolute_error: 0.0032
    Epoch 89/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.3524e-05 - mean_absolute_error: 0.0033 - val_loss: 2.8969e-05 - val_mean_absolute_error: 0.0034
    Epoch 90/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.3043e-05 - mean_absolute_error: 0.0033 - val_loss: 2.4465e-05 - val_mean_absolute_error: 0.0037
    Epoch 91/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.3404e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3801e-05 - val_mean_absolute_error: 0.0032
    Epoch 92/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2195e-05 - mean_absolute_error: 0.0033 - val_loss: 2.6116e-05 - val_mean_absolute_error: 0.0034
    Epoch 93/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.4265e-05 - mean_absolute_error: 0.0034 - val_loss: 2.5325e-05 - val_mean_absolute_error: 0.0035
    Epoch 94/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.2766e-05 - mean_absolute_error: 0.0033 - val_loss: 2.5981e-05 - val_mean_absolute_error: 0.0034
    Epoch 95/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.2876e-05 - mean_absolute_error: 0.0033 - val_loss: 2.4724e-05 - val_mean_absolute_error: 0.0033
    Epoch 96/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.2957e-05 - mean_absolute_error: 0.0033 - val_loss: 2.7571e-05 - val_mean_absolute_error: 0.0034
    Epoch 97/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.2512e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3335e-05 - val_mean_absolute_error: 0.0035
    Epoch 98/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2625e-05 - mean_absolute_error: 0.0033 - val_loss: 2.4474e-05 - val_mean_absolute_error: 0.0033
    Epoch 99/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2732e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3824e-05 - val_mean_absolute_error: 0.0032
    Epoch 100/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.0567e-05 - mean_absolute_error: 0.0032 - val_loss: 2.5172e-05 - val_mean_absolute_error: 0.0034
    Epoch 101/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2362e-05 - mean_absolute_error: 0.0033 - val_loss: 2.4723e-05 - val_mean_absolute_error: 0.0033
    Epoch 102/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.2565e-05 - mean_absolute_error: 0.0033 - val_loss: 2.7148e-05 - val_mean_absolute_error: 0.0035
    Epoch 103/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.3219e-05 - mean_absolute_error: 0.0033 - val_loss: 2.6632e-05 - val_mean_absolute_error: 0.0035
    Epoch 104/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.3395e-05 - mean_absolute_error: 0.0033 - val_loss: 2.9213e-05 - val_mean_absolute_error: 0.0034
    Epoch 105/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2053e-05 - mean_absolute_error: 0.0033 - val_loss: 2.2147e-05 - val_mean_absolute_error: 0.0032
    Epoch 106/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.1957e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3650e-05 - val_mean_absolute_error: 0.0033
    Epoch 107/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.2505e-05 - mean_absolute_error: 0.0033 - val_loss: 2.7094e-05 - val_mean_absolute_error: 0.0033
    Epoch 108/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.3697e-05 - mean_absolute_error: 0.0033 - val_loss: 2.5232e-05 - val_mean_absolute_error: 0.0033
    Epoch 109/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.1201e-05 - mean_absolute_error: 0.0032 - val_loss: 2.3246e-05 - val_mean_absolute_error: 0.0032
    Epoch 110/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.1813e-05 - mean_absolute_error: 0.0033 - val_loss: 2.2914e-05 - val_mean_absolute_error: 0.0032
    Epoch 111/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2045e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3515e-05 - val_mean_absolute_error: 0.0032
    Epoch 112/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2180e-05 - mean_absolute_error: 0.0033 - val_loss: 3.7018e-05 - val_mean_absolute_error: 0.0041
    Epoch 113/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.4374e-05 - mean_absolute_error: 0.0035 - val_loss: 2.5627e-05 - val_mean_absolute_error: 0.0032
    Epoch 114/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.1670e-05 - mean_absolute_error: 0.0033 - val_loss: 2.5143e-05 - val_mean_absolute_error: 0.0033
    Epoch 115/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.1445e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2952e-05 - val_mean_absolute_error: 0.0033
    Epoch 116/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.0803e-05 - mean_absolute_error: 0.0032 - val_loss: 2.3628e-05 - val_mean_absolute_error: 0.0034
    Epoch 117/200
    1310/1310 [==============================] - 0s 367us/step - loss: 2.1477e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2852e-05 - val_mean_absolute_error: 0.0034
    Epoch 118/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.1262e-05 - mean_absolute_error: 0.0032 - val_loss: 2.8066e-05 - val_mean_absolute_error: 0.0037
    Epoch 119/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.2442e-05 - mean_absolute_error: 0.0033 - val_loss: 2.4395e-05 - val_mean_absolute_error: 0.0033
    Epoch 120/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.1218e-05 - mean_absolute_error: 0.0032 - val_loss: 2.6158e-05 - val_mean_absolute_error: 0.0038
    Epoch 121/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.1836e-05 - mean_absolute_error: 0.0032 - val_loss: 2.5108e-05 - val_mean_absolute_error: 0.0034
    Epoch 122/200
    1310/1310 [==============================] - 0s 374us/step - loss: 2.0698e-05 - mean_absolute_error: 0.0032 - val_loss: 2.4667e-05 - val_mean_absolute_error: 0.0034
    Epoch 123/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2541e-05 - mean_absolute_error: 0.0034 - val_loss: 2.3767e-05 - val_mean_absolute_error: 0.0035
    Epoch 124/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.1079e-05 - mean_absolute_error: 0.0032 - val_loss: 2.4143e-05 - val_mean_absolute_error: 0.0032
    Epoch 125/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.2073e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3275e-05 - val_mean_absolute_error: 0.0034
    Epoch 126/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.0761e-05 - mean_absolute_error: 0.0032 - val_loss: 2.6003e-05 - val_mean_absolute_error: 0.0035
    Epoch 127/200
    1310/1310 [==============================] - 0s 372us/step - loss: 1.9863e-05 - mean_absolute_error: 0.0031 - val_loss: 2.4220e-05 - val_mean_absolute_error: 0.0034
    Epoch 128/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.0810e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2280e-05 - val_mean_absolute_error: 0.0032
    Epoch 129/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2249e-05 - mean_absolute_error: 0.0032 - val_loss: 2.4652e-05 - val_mean_absolute_error: 0.0037
    Epoch 130/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.0200e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2830e-05 - val_mean_absolute_error: 0.0033
    Epoch 131/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.0107e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3593e-05 - val_mean_absolute_error: 0.0033
    Epoch 132/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.1333e-05 - mean_absolute_error: 0.0033 - val_loss: 2.2135e-05 - val_mean_absolute_error: 0.0032
    Epoch 133/200
    1310/1310 [==============================] - 0s 370us/step - loss: 2.0900e-05 - mean_absolute_error: 0.0032 - val_loss: 2.6643e-05 - val_mean_absolute_error: 0.0036
    Epoch 134/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.2272e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3478e-05 - val_mean_absolute_error: 0.0033
    Epoch 135/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.0098e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1405e-05 - val_mean_absolute_error: 0.0032
    Epoch 136/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.0423e-05 - mean_absolute_error: 0.0031 - val_loss: 2.0977e-05 - val_mean_absolute_error: 0.0032
    Epoch 137/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.0939e-05 - mean_absolute_error: 0.0032 - val_loss: 2.7091e-05 - val_mean_absolute_error: 0.0036
    Epoch 138/200
    1310/1310 [==============================] - 0s 376us/step - loss: 2.0957e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2917e-05 - val_mean_absolute_error: 0.0033
    Epoch 139/200
    1310/1310 [==============================] - 0s 376us/step - loss: 2.0738e-05 - mean_absolute_error: 0.0032 - val_loss: 2.6044e-05 - val_mean_absolute_error: 0.0033
    Epoch 140/200
    1310/1310 [==============================] - 0s 378us/step - loss: 1.9861e-05 - mean_absolute_error: 0.0031 - val_loss: 2.8615e-05 - val_mean_absolute_error: 0.0036
    Epoch 141/200
    1310/1310 [==============================] - 0s 373us/step - loss: 2.1651e-05 - mean_absolute_error: 0.0033 - val_loss: 2.3652e-05 - val_mean_absolute_error: 0.0033
    Epoch 142/200
    1310/1310 [==============================] - 0s 379us/step - loss: 1.9867e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1538e-05 - val_mean_absolute_error: 0.0033
    Epoch 143/200
    1310/1310 [==============================] - 0s 377us/step - loss: 2.1249e-05 - mean_absolute_error: 0.0032 - val_loss: 2.3244e-05 - val_mean_absolute_error: 0.0033
    Epoch 144/200
    1310/1310 [==============================] - 0s 376us/step - loss: 1.9655e-05 - mean_absolute_error: 0.0031 - val_loss: 2.5116e-05 - val_mean_absolute_error: 0.0033
    Epoch 145/200
    1310/1310 [==============================] - 0s 377us/step - loss: 2.0584e-05 - mean_absolute_error: 0.0031 - val_loss: 2.0742e-05 - val_mean_absolute_error: 0.0031
    Epoch 146/200
    1310/1310 [==============================] - 0s 379us/step - loss: 2.1047e-05 - mean_absolute_error: 0.0032 - val_loss: 2.5242e-05 - val_mean_absolute_error: 0.0034
    Epoch 147/200
    1310/1310 [==============================] - 0s 375us/step - loss: 2.0653e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2351e-05 - val_mean_absolute_error: 0.0032
    Epoch 148/200
    1310/1310 [==============================] - 0s 376us/step - loss: 1.9468e-05 - mean_absolute_error: 0.0031 - val_loss: 1.9919e-05 - val_mean_absolute_error: 0.0033
    Epoch 149/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.8819e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2008e-05 - val_mean_absolute_error: 0.0033
    Epoch 150/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.0283e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3393e-05 - val_mean_absolute_error: 0.0032
    Epoch 151/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.0366e-05 - mean_absolute_error: 0.0032 - val_loss: 2.3043e-05 - val_mean_absolute_error: 0.0032
    Epoch 152/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9816e-05 - mean_absolute_error: 0.0032 - val_loss: 2.3973e-05 - val_mean_absolute_error: 0.0033
    Epoch 153/200
    1310/1310 [==============================] - 0s 372us/step - loss: 2.0027e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1103e-05 - val_mean_absolute_error: 0.0032
    Epoch 154/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.9629e-05 - mean_absolute_error: 0.0031 - val_loss: 2.5291e-05 - val_mean_absolute_error: 0.0034
    Epoch 155/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.0331e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1587e-05 - val_mean_absolute_error: 0.0032
    Epoch 156/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9426e-05 - mean_absolute_error: 0.0031 - val_loss: 2.0838e-05 - val_mean_absolute_error: 0.0033
    Epoch 157/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9643e-05 - mean_absolute_error: 0.0032 - val_loss: 2.1426e-05 - val_mean_absolute_error: 0.0032
    Epoch 158/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9466e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2608e-05 - val_mean_absolute_error: 0.0032
    Epoch 159/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9767e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2664e-05 - val_mean_absolute_error: 0.0032
    Epoch 160/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.9180e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1267e-05 - val_mean_absolute_error: 0.0031
    Epoch 161/200
    1310/1310 [==============================] - 0s 367us/step - loss: 1.9574e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1347e-05 - val_mean_absolute_error: 0.0032
    Epoch 162/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.8670e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3202e-05 - val_mean_absolute_error: 0.0032
    Epoch 163/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.9914e-05 - mean_absolute_error: 0.0031 - val_loss: 2.8114e-05 - val_mean_absolute_error: 0.0035
    Epoch 164/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.1188e-05 - mean_absolute_error: 0.0032 - val_loss: 1.9665e-05 - val_mean_absolute_error: 0.0031
    Epoch 165/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.8901e-05 - mean_absolute_error: 0.0031 - val_loss: 2.7330e-05 - val_mean_absolute_error: 0.0034
    Epoch 166/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.0182e-05 - mean_absolute_error: 0.0031 - val_loss: 2.4725e-05 - val_mean_absolute_error: 0.0033
    Epoch 167/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9397e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3711e-05 - val_mean_absolute_error: 0.0034
    Epoch 168/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.8547e-05 - mean_absolute_error: 0.0030 - val_loss: 2.0614e-05 - val_mean_absolute_error: 0.0032
    Epoch 169/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9909e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3632e-05 - val_mean_absolute_error: 0.0032
    Epoch 170/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9466e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1093e-05 - val_mean_absolute_error: 0.0032
    Epoch 171/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.0114e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2105e-05 - val_mean_absolute_error: 0.0033
    Epoch 172/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9409e-05 - mean_absolute_error: 0.0031 - val_loss: 2.4240e-05 - val_mean_absolute_error: 0.0033
    Epoch 173/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9158e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1822e-05 - val_mean_absolute_error: 0.0032
    Epoch 174/200
    1310/1310 [==============================] - 0s 368us/step - loss: 2.0871e-05 - mean_absolute_error: 0.0032 - val_loss: 2.4051e-05 - val_mean_absolute_error: 0.0034
    Epoch 175/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9431e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1750e-05 - val_mean_absolute_error: 0.0032
    Epoch 176/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.8312e-05 - mean_absolute_error: 0.0030 - val_loss: 2.3182e-05 - val_mean_absolute_error: 0.0035
    Epoch 177/200
    1310/1310 [==============================] - 0s 372us/step - loss: 1.9770e-05 - mean_absolute_error: 0.0031 - val_loss: 2.0688e-05 - val_mean_absolute_error: 0.0032
    Epoch 178/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9754e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3640e-05 - val_mean_absolute_error: 0.0032
    Epoch 179/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9065e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3215e-05 - val_mean_absolute_error: 0.0034
    Epoch 180/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.8429e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1985e-05 - val_mean_absolute_error: 0.0032
    Epoch 181/200
    1310/1310 [==============================] - 0s 369us/step - loss: 2.0310e-05 - mean_absolute_error: 0.0032 - val_loss: 2.2887e-05 - val_mean_absolute_error: 0.0032
    Epoch 182/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9336e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2310e-05 - val_mean_absolute_error: 0.0032
    Epoch 183/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.8938e-05 - mean_absolute_error: 0.0031 - val_loss: 2.4724e-05 - val_mean_absolute_error: 0.0033
    Epoch 184/200
    1310/1310 [==============================] - 0s 367us/step - loss: 1.8534e-05 - mean_absolute_error: 0.0030 - val_loss: 2.0347e-05 - val_mean_absolute_error: 0.0032
    Epoch 185/200
    1310/1310 [==============================] - 0s 372us/step - loss: 1.8187e-05 - mean_absolute_error: 0.0030 - val_loss: 2.0731e-05 - val_mean_absolute_error: 0.0031
    Epoch 186/200
    1310/1310 [==============================] - 0s 367us/step - loss: 1.8369e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1355e-05 - val_mean_absolute_error: 0.0033
    Epoch 187/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.9809e-05 - mean_absolute_error: 0.0031 - val_loss: 1.9429e-05 - val_mean_absolute_error: 0.0032
    Epoch 188/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.9665e-05 - mean_absolute_error: 0.0031 - val_loss: 2.3814e-05 - val_mean_absolute_error: 0.0033
    Epoch 189/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.8086e-05 - mean_absolute_error: 0.0030 - val_loss: 2.2395e-05 - val_mean_absolute_error: 0.0032
    Epoch 190/200
    1310/1310 [==============================] - 0s 371us/step - loss: 2.0321e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1612e-05 - val_mean_absolute_error: 0.0033
    Epoch 191/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9057e-05 - mean_absolute_error: 0.0030 - val_loss: 2.2368e-05 - val_mean_absolute_error: 0.0032
    Epoch 192/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.9716e-05 - mean_absolute_error: 0.0031 - val_loss: 2.4474e-05 - val_mean_absolute_error: 0.0033
    Epoch 193/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.8182e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1238e-05 - val_mean_absolute_error: 0.0031
    Epoch 194/200
    1310/1310 [==============================] - 0s 369us/step - loss: 1.7766e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1708e-05 - val_mean_absolute_error: 0.0031
    Epoch 195/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.7650e-05 - mean_absolute_error: 0.0030 - val_loss: 2.4246e-05 - val_mean_absolute_error: 0.0033
    Epoch 196/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.9271e-05 - mean_absolute_error: 0.0031 - val_loss: 2.1489e-05 - val_mean_absolute_error: 0.0032
    Epoch 197/200
    1310/1310 [==============================] - 0s 368us/step - loss: 1.8483e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1907e-05 - val_mean_absolute_error: 0.0035
    Epoch 198/200
    1310/1310 [==============================] - 0s 370us/step - loss: 1.8185e-05 - mean_absolute_error: 0.0030 - val_loss: 2.1979e-05 - val_mean_absolute_error: 0.0031
    Epoch 199/200
    1310/1310 [==============================] - 0s 371us/step - loss: 1.7280e-05 - mean_absolute_error: 0.0029 - val_loss: 2.2062e-05 - val_mean_absolute_error: 0.0033
    Epoch 200/200
    1310/1310 [==============================] - 0s 367us/step - loss: 1.9480e-05 - mean_absolute_error: 0.0031 - val_loss: 2.2369e-05 - val_mean_absolute_error: 0.0032



```python
print(history_advanced.history.keys())
# summarize history for accuracy
plt.plot(history_advanced.history['mean_absolute_error'])
plt.plot(history_advanced.history['val_mean_absolute_error'])
plt.title('Advanced Model MAE')
plt.ylabel('Mean Absolute Error (1$)')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()
```

    dict_keys(['val_loss', 'val_mean_absolute_error', 'loss', 'mean_absolute_error'])



![png](output_62_1.png)



```python
# summarize history for loss
plt.plot(history_advanced.history['loss'])
plt.plot(history_advanced.history['val_loss'])
plt.title('Advanced Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()
```


![png](output_63_0.png)



```python
Y_test = advanced_model.predict(test_df)
```


```python
Y_2 = advanced_model.predict(X_val)
```


```python
for val in Y_test:
    print("Total Cases By Year : ", int((val*461)**2))
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-1-2f9eb86d5efd> in <module>()
    ----> 1 for val in Y_test:
          2     print("Total Cases By Year : ",int((val*461)**2))


    NameError: name 'Y_test' is not defined

